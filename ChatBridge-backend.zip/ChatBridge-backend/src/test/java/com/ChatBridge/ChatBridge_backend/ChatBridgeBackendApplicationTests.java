package com.ChatBridge.ChatBridge_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatBridgeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
